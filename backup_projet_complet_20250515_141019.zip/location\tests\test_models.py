from django.test import TestCase
from django.core.exceptions import ValidationError
from location.models import User, Voiture, Reservation, Paiement, DeliveryOption
from datetime import date, timedelta
from django.utils import timezone

class UserModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            user_type='LOUEUR',
            phone='+2250700000000'
        )

    def test_user_creation(self):
        self.assertEqual(self.user.user_type, 'LOUEUR')
        self.assertFalse(self.user.is_verified)

    def test_proprietaire_profile_creation(self):
        proprietaire = User.objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        self.assertEqual(proprietaire.proprietaire_profile.cin, '')


class VoitureModelTest(TestCase):
    def setUp(self):
        self.proprietaire = User.objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        self.voiture = Voiture.objects.create(
            proprietaire=self.proprietaire,
            marque='Toyota',
            modele='Corolla',
            annee=2020,
            prix_jour=25000,
            ville='Abidjan'
        )

    def test_voiture_creation(self):
        self.assertEqual(self.voiture.marque, 'Toyota')
        self.assertTrue(self.voiture.disponible)

    def test_voiture_clean_validation(self):
        # Test année invalide
        self.voiture.annee = timezone.now().year + 2
        with self.assertRaises(ValidationError):
            self.voiture.full_clean()


class ReservationModelTest(TestCase):
    def setUp(self):
        self.proprietaire = User.objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        self.loueur = User.objects.create_user(
            username='loueur',
            password='testpass',
            user_type='LOUEUR',
            phone='+2250700000000'
        )
        self.voiture = Voiture.objects.create(
            proprietaire=self.proprietaire,
            marque='Toyota',
            modele='Corolla',
            annee=2020,
            prix_jour=25000,
            ville='Abidjan'
        )
        self.reservation = Reservation.objects.create(
            voiture=self.voiture,
            client=self.loueur,
            date_debut=date.today() + timedelta(days=1),
            date_fin=date.today() + timedelta(days=3),
            montant_paye=75000,
            statut='attente_paiement'
        )

    def test_reservation_creation(self):
        self.assertEqual(self.reservation.duree, 2)
        self.assertEqual(self.reservation.statut, 'attente_paiement')

    def test_commission_calculation(self):
        commissions = self.reservation.calculer_commissions()
        self.assertIn('commission_proprietaire', commissions)


class DeliveryModelTest(TestCase):
    def setUp(self):
        self.option = DeliveryOption.objects.create(
            name='Standard',
            delivery_type='STANDARD',
            price=5000
        )

    def test_delivery_option_creation(self):
        self.assertEqual(self.option.delivery_type, 'STANDARD')
        self.assertEqual(self.option.price, 5000)