from django.db import transaction
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models.core_models import Portefeuille, Transaction, DocumentVerification, Reservation, Voiture, User, ProprietaireProfile
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from .models.delivery_models import DeliveryOption, DeliveryRequest
from django.contrib.auth.models import Group
from django.utils.html import format_html
from location.notifications.models import Notification
from django.utils import timezone
from django.urls import reverse
from django.template.defaultfilters import register

# Configuration de base
admin.site.site_header = "Administration de MonCaisson"
admin.site.site_title = "Plateforme MonCaisson"
admin.site.index_title = "Accueil de l'administration"
admin.site.register(Notification)

# Désenregistrement des modèles existants
for model in [User, Voiture, Reservation, DocumentVerification, DeliveryOption, DeliveryRequest, ProprietaireProfile]:
    if model in admin.site._registry:
        admin.site.unregister(model)

# Filtres personnalisés
@register.filter
def filter_docs_verified(queryset):
    return [x for x in queryset if x.documents_verified]

@register.filter
def filter_docs_complete(queryset):
    return [x for x in queryset if x.assurance_document and x.carte_grise_document]

@register.filter
def filter_docs_partial(queryset):
    return [x for x in queryset if (x.assurance_document or x.carte_grise_document) 
            and not (x.assurance_document and x.carte_grise_document)]

@register.filter
def filter_docs_missing(queryset):
    return [x for x in queryset if not x.assurance_document and not x.carte_grise_document]

# Configuration améliorée pour ProprietaireProfile
@admin.register(ProprietaireProfile)
class ProprietaireProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'cin', 'documents_status', 'verification_badge', 'created_at')
    list_filter = ('user__verification_status', 'documents_verified')
    search_fields = ('user__username', 'user__email', 'cin')
    readonly_fields = ('documents_preview', 'verification_status', 'created_at')
    date_hierarchy = 'user__date_joined'
    list_per_page = 25
    actions = ['approve_selected', 'reject_selected']
    raw_id_fields = ('user',)

    fieldsets = (
        (None, {
            'fields': ('user', 'cin', 'address')
        }),
        ('Documents', {
            'fields': ('assurance_document', 'carte_grise_document', 'documents_preview'),
            'classes': ('collapse',)
        }),
        ('Vérification', {
            'fields': ('documents_verified', 'verification_status', 'admin_notes'),
            'classes': ('collapse',)
        }),
    )

    def documents_status(self, obj):
        assurance = "✓" if obj.assurance_document else "✗"
        carte_grise = "✓" if obj.carte_grise_document else "✗"
        return format_html(
            '<span style="font-family:monospace">Assurance: {} | C.Grise: {}</span>',
            assurance, carte_grise
        )
    documents_status.short_description = "Documents"

    def documents_preview(self, obj):
        previews = []
        if obj.assurance_document:
            previews.append(f"""
                <div style="margin-bottom:20px">
                    <h4>Assurance</h4>
                    <a href="{obj.assurance_document.url}" target="_blank">
                        <img src="{obj.assurance_document.url}" style="max-height:200px;max-width:100%">
                    </a>
                    <div style="margin-top:5px">
                        <a href="{obj.assurance_document.url}" download class="button">Télécharger</a>
                    </div>
                </div>
            """)
        if obj.carte_grise_document:
            previews.append(f"""
                <div style="margin-bottom:20px">
                    <h4>Carte Grise</h4>
                    <a href="{obj.carte_grise_document.url}" target="_blank">
                        <img src="{obj.carte_grise_document.url}" style="max-height:200px;max-width:100%">
                    </a>
                    <div style="margin-top:5px">
                        <a href="{obj.carte_grise_document.url}" download class="button">Télécharger</a>
                    </div>
                </div>
            """)
        return format_html(''.join(previews)) if previews else "Aucun document"
    documents_preview.short_description = "Prévisualisation"

    def verification_badge(self, obj):
        status = obj.user.verification_status
        colors = {
            'approved': ('green', '✓'),
            'pending': ('orange', '⏳'),
            'rejected': ('red', '✗'),
            'documents_required': ('gray', '📄')
        }
        color, icon = colors.get(status, ('black', '?'))
        return format_html(
            '<span style="color:{};font-weight:bold">{} {}</span>',
            color, icon, obj.user.get_verification_status_display()
        )
    verification_badge.short_description = "Statut"
    verification_badge.admin_order_field = 'user__verification_status'

    def verification_status(self, obj):
        return self.verification_badge(obj)
    verification_status.short_description = "Statut de vérification"

    def created_at(self, obj):
        return obj.user.date_joined.strftime("%Y-%m-%d %H:%M")
    created_at.short_description = "Inscrit le"

    @admin.action(description="Approuver les sélections")
    def approve_selected(self, request, queryset):
        updated = queryset.update(
            documents_verified=True,
            verification_date=timezone.now()
        )
        queryset.update(user__verification_status='approved', user__is_verified=True)
        self.message_user(request, f"{updated} profil(s) approuvé(s)")

    @admin.action(description="Rejeter les sélections")
    def reject_selected(self, request, queryset):
        updated = queryset.update(
            documents_verified=False,
            verification_date=None
        )
        queryset.update(user__verification_status='rejected', user__is_verified=False)
        self.message_user(request, f"{updated} profil(s) rejeté(s)")

    def save_model(self, request, obj, form, change):
        # Mise à jour automatique du statut selon les documents
        has_docs = obj.assurance_document and obj.carte_grise_document
        obj.documents_verified = has_docs
        obj.verification_date = timezone.now() if has_docs else None
        
        obj.user.verification_status = 'approved' if has_docs else 'documents_required'
        obj.user.is_verified = has_docs
        obj.user.save()
        
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')

    class Media:
        css = {
            'all': ('admin/css/admin-custom.css',)
        }

# Configuration DocumentVerification
@admin.register(DocumentVerification)
class DocumentVerificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'status', 'documents_count', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('user__username', 'user__email')
    readonly_fields = ('documents_list', 'user_link')
    actions = ['approve_verification', 'reject_verification']
    
    fieldsets = (
        (None, {
            'fields': ('user_link', 'status', 'notes')
        }),
        ('Documents', {
            'fields': ('documents_list',),
            'classes': ('collapse',)
        }),
    )

    def documents_count(self, obj):
        count = sum([1 for field in ['id_card', 'vehicle_insurance', 'registration_card', 
                                    'driver_license', 'passport', 'selfie'] if getattr(obj, field)])
        return f"{count} document(s)"
    documents_count.short_description = "Documents"

    def documents_list(self, obj):
        docs = []
        doc_fields = [
            ('id_card', "Carte d'identité"),
            ('vehicle_insurance', "Assurance véhicule"),
            ('registration_card', "Carte grise"),
            ('driver_license', "Permis de conduire"),
            ('passport', "Passeport"),
            ('selfie', "Selfie")
        ]
        
        for field, label in doc_fields:
            if getattr(obj, field):
                docs.append(f"""
                    <div style="margin-bottom:15px;border-bottom:1px solid #eee;padding-bottom:15px;">
                        <h4>{label}</h4>
                        <a href="{getattr(obj, field).url}" target="_blank">
                            <img src="{getattr(obj, field).url}" style="max-height:200px;max-width:100%;"/>
                        </a>
                    </div>
                """)
        return format_html(''.join(docs)) if docs else "Aucun document uploadé"
    documents_list.short_description = "Documents"

    def user_link(self, obj):
        url = reverse('admin:location_user_change', args=[obj.user.id])
        return format_html('<a href="{}">{}</a>', url, obj.user)
    user_link.short_description = "Utilisateur"

    @admin.action(description="Approuver les vérifications")
    def approve_verification(self, request, queryset):
        queryset.update(status='approuve')
        for verification in queryset:
            verification.user.is_verified = True
            verification.user.verification_status = 'approved'
            verification.user.save()
        self.message_user(request, f"{queryset.count()} vérification(s) approuvée(s)")

    @admin.action(description="Rejeter les vérifications")
    def reject_verification(self, request, queryset):
        queryset.update(status='rejete')
        for verification in queryset:
            verification.user.is_verified = False
            verification.user.verification_status = 'rejected'
            verification.user.save()
        self.message_user(request, f"{queryset.count()} vérification(s) rejetée(s)")

# Configuration User
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'user_type', 'is_verified', 'trust_score', 'verification_status', 'documents_status')
    list_filter = ('user_type', 'is_verified', 'verification_status')
    search_fields = ('username', 'email')
    actions = ['approve_users', 'reject_users', 'verify_documents']
    readonly_fields = ('documents_status', 'proprietaire_link')
    
    fieldsets = UserAdmin.fieldsets + (
        ('Informations supplémentaires', {
            'fields': ('user_type', 'phone', 'city', 'country', 'photo')
        }),
        ('Vérification', {
            'fields': ('is_verified', 'trust_score', 'verification_status')
        }),
        ('Documents', {
            'fields': ('documents_status', 'proprietaire_link'),
            'classes': ('collapse',)
        }),
    )

    def documents_status(self, obj):
        if obj.user_type == 'PROPRIETAIRE':
            try:
                profile = obj.proprietaire_profile
                docs = []
                if profile.assurance_document:
                    docs.append(f'<a href="{profile.assurance_document.url}" target="_blank">Assurance</a>')
                if profile.carte_grise_document:
                    docs.append(f'<a href="{profile.carte_grise_document.url}" target="_blank">Carte Grise</a>')
                status = "✓ Validé" if profile.documents_verified else "✗ En attente"
                return format_html("{}<br>Statut: {}", " | ".join(docs) if docs else "Aucun document", status)
            except ProprietaireProfile.DoesNotExist:
                return "Profil manquant"
        return "N/A"
    documents_status.short_description = "Documents"

    def proprietaire_link(self, obj):
        if obj.user_type == 'PROPRIETAIRE':
            try:
                url = reverse('admin:location_proprietaireprofile_change', args=[obj.proprietaire_profile.id])
                return format_html('<a href="{}">Voir le profil complet</a>', url)
            except ProprietaireProfile.DoesNotExist:
                return "Profil non créé"
        return "N/A"
    proprietaire_link.short_description = "Lien profil"

    @admin.action(description="Approuver les utilisateurs")
    def approve_users(self, request, queryset):
        updated = queryset.update(is_verified=True, verification_status='approved')
        self.message_user(request, f"{updated} utilisateur(s) approuvé(s)")

    @admin.action(description="Rejeter les utilisateurs")
    def reject_users(self, request, queryset):
        updated = queryset.update(is_verified=False, verification_status='rejected')
        self.message_user(request, f"{updated} utilisateur(s) rejeté(s)")

    @admin.action(description="Valider les documents")
    def verify_documents(self, request, queryset):
        count = 0
        for user in queryset.filter(user_type='PROPRIETAIRE'):
            profile, created = ProprietaireProfile.objects.get_or_create(user=user)
            profile.documents_verified = True
            profile.verification_date = timezone.now()
            profile.save()
            count += 1
        self.message_user(request, f"Documents validés pour {count} propriétaire(s)")

# Configuration Voiture
class VoitureResource(resources.ModelResource):
    class Meta:
        model = Voiture
        fields = ('id', 'marque', 'modele', 'proprietaire__username', 'ville', 'prix_jour')

@admin.register(Voiture)
class VoitureAdmin(ImportExportModelAdmin):
    resource_class = VoitureResource
    list_display = ('marque', 'modele', 'proprietaire', 'ville', 'prix_jour', 'disponible')
    list_filter = ('ville', 'type_vehicule', 'disponible')
    search_fields = ('marque', 'modele', 'proprietaire__username')
    raw_id_fields = ('proprietaire',)
    readonly_fields = ('photo_preview',)
    
    fieldsets = (
        ('Informations générales', {
            'fields': ('proprietaire', 'marque', 'modele', 'annee', 'ville', 'description')
        }),
        ('Caractéristiques', {
            'fields': ('type_vehicule', 'transmission', 'carburant', 'kilometrage', 'nb_places', 'nb_portes')
        }),
        ('Équipements', {
            'fields': ('climatisation', 'gps', 'siege_bebe', 'bluetooth')
        }),
        ('Tarification', {
            'fields': ('prix_jour', 'avec_chauffeur', 'prix_chauffeur')
        }),
        ('Visuel', {
            'fields': ('photo', 'photo_preview')
        }),
    )

    def photo_preview(self, obj):
        if obj.photo:
            return format_html('<img src="{}" style="max-height:200px;"/>', obj.photo.url)
        return "Aucune photo"
    photo_preview.short_description = "Prévisualisation"

# Configuration Reservation
class ReservationResource(resources.ModelResource):
    class Meta:
        model = Reservation
        fields = ('id', 'voiture__marque', 'client__username', 'date_debut', 'date_fin', 'statut')

@admin.register(Reservation)
class ReservationAdmin(ImportExportModelAdmin):
    resource_class = ReservationResource
    list_display = ('id', 'voiture', 'client', 'statut', 'date_debut', 'date_fin')
    list_filter = ('statut', 'date_debut')
    search_fields = ('voiture__marque', 'client__username')
    raw_id_fields = ('voiture', 'client')
    date_hierarchy = 'date_debut'

# Configuration Livraison
@admin.register(DeliveryOption)
class DeliveryOptionAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'is_active')
    list_editable = ('price', 'is_active')

@admin.register(DeliveryRequest)
class DeliveryRequestAdmin(admin.ModelAdmin):
    list_display = ('reservation', 'status', 'requested_date')
    list_filter = ('status', 'delivery_option')
    raw_id_fields = ('reservation', 'driver')

# Configuration financière
@admin.register(Portefeuille)
class PortefeuilleAdmin(admin.ModelAdmin):
    list_display = ('proprietaire', 'solde_display')
    search_fields = ('proprietaire__username',)
    
    def solde_display(self, obj):
        color = 'green' if obj.solde >= 0 else 'red'
        return format_html('<span style="color:{}">{:.2f} XOF</span>', color, obj.solde)
    solde_display.short_description = "Solde"

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('reference', 'portefeuille', 'montant_display', 'type_transaction', 'statut', 'date')
    list_filter = ('type_transaction', 'statut')
    
    def montant_display(self, obj):
        color = 'green' if obj.montant >= 0 else 'red'
        return format_html('<span style="color:{}">{:.2f} XOF</span>', color, obj.montant)
    montant_display.short_description = "Montant"