from rest_framework.test import APITestCase
from rest_framework import status
from location.models import DeliveryOption, DeliveryRequest, User, Voiture, Reservation

class DeliveryAPITest(APITestCase):
    def setUp(self):
        self.option = DeliveryOption.objects.create(
            name='Standard',
            delivery_type='STANDARD',
            price=5000,
            is_active=True
        )
        
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            user_type='LOUEUR',
            phone='+2250700000000'
        )
        
        self.proprietaire = User.objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        
        self.voiture = Voiture.objects.create(
            proprietaire=self.proprietaire,
            marque='Toyota',
            modele='Corolla',
            annee=2020,
            prix_jour=25000,
            ville='Abidjan'
        )
        
        self.reservation = Reservation.objects.create(
            voiture=self.voiture,
            client=self.user,
            date_debut='2023-12-01',
            date_fin='2023-12-03',
            montant_paye=75000,
            statut='confirme'
        )
        
        self.client.force_authenticate(user=self.user)

    def test_list_delivery_options(self):
        url = '/api/delivery/options/'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_create_delivery_request(self):
        url = '/api/delivery/requests/'
        data = {
            'reservation': self.reservation.id,
            'voiture': self.voiture.id,
            'delivery_option': self.option.id,
            'delivery_address': 'Cocody, Abidjan',
            'requested_date': '2023-12-01T10:00:00Z'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(DeliveryRequest.objects.count(), 1)

    def test_delivery_request_status_update(self):
        delivery = DeliveryRequest.objects.create(
            reservation=self.reservation,
            user=self.user,
            voiture=self.voiture,
            delivery_option=self.option,
            delivery_address='Cocody, Abidjan',
            status='PENDING'
        )
        
        url = f'/api/delivery/requests/{delivery.id}/'
        data = {'status': 'ACCEPTED'}
        response = self.client.patch(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['status'], 'ACCEPTED')