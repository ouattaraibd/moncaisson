from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from location.models import Voiture, Reservation, DeliveryOption

class AuthViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = get_user_model().objects.create_user(
            username='testuser',
            password='testpass123',
            user_type='LOUEUR',
            phone='+2250700000000'
        )

    def test_connexion_view(self):
        response = self.client.post(reverse('connexion'), {
            'username': 'testuser',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, 302)  # Redirection après connexion

    def test_register_loueur_view(self):
        response = self.client.post(reverse('register_loueur'), {
            'username': 'newuser',
            'password1': 'complexpass123',
            'password2': 'complexpass123',
            'phone': '+2250102030405',
            'user_type': 'LOUEUR'
        })
        self.assertEqual(response.status_code, 302)  # Redirection après inscription


class ReservationViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.proprietaire = get_user_model().objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        self.loueur = get_user_model().objects.create_user(
            username='loueur',
            password='testpass',
            user_type='LOUEUR',
            phone='+2250700000000'
        )
        self.voiture = Voiture.objects.create(
            proprietaire=self.proprietaire,
            marque='Toyota',
            modele='Corolla',
            annee=2020,
            prix_jour=25000,
            ville='Abidjan'
        )
        self.client.force_login(self.loueur)

    def test_reserver_voiture_view(self):
        url = reverse('reserver_voiture', args=[self.voiture.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_reservation_creation(self):
        url = reverse('reserver_voiture', args=[self.voiture.id])
        response = self.client.post(url, {
            'date_debut': '2023-12-01',
            'date_fin': '2023-12-03'
        })
        self.assertEqual(response.status_code, 302)  # Redirection après réservation


class PaymentViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.proprietaire = get_user_model().objects.create_user(
            username='proprio',
            password='testpass',
            user_type='PROPRIETAIRE',
            phone='+2250100000000'
        )
        self.loueur = get_user_model().objects.create_user(
            username='loueur',
            password='testpass',
            user_type='LOUEUR',
            phone='+2250700000000'
        )
        self.voiture = Voiture.objects.create(
            proprietaire=self.proprietaire,
            marque='Toyota',
            modele='Corolla',
            annee=2020,
            prix_jour=25000,
            ville='Abidjan'
        )
        self.reservation = Reservation.objects.create(
            voiture=self.voiture,
            client=self.loueur,
            date_debut='2023-12-01',
            date_fin='2023-12-03',
            montant_paye=75000,
            statut='attente_paiement'
        )
        self.client.force_login(self.loueur)

    def test_initier_paiement_view(self):
        url = reverse('initier_paiement', args=[self.reservation.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)