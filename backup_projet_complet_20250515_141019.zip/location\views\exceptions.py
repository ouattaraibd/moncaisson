class PaymentInitError(Exception):
    """Exception personnalisée pour les erreurs d'initialisation de paiement"""
    pass