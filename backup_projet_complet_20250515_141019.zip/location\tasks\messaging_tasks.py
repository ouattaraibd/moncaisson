from celery import shared_task
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from location.models import Message
import logging

logger = logging.getLogger(__name__)

@shared_task(
    bind=True,
    autoretry_for=(Exception,),
    retry_backoff=60,
    retry_kwargs={'max_retries': 3}
)

@shared_task(bind=True)
def send_message_notification
    """
    Tâche Celery pour notifier les participants d'un nouveau message
    """
    try:
        message = Message.objects.select_related(
            'conversation',
            'sender'
        ).get(id=message_id)
        
        recipients = message.conversation.participants.exclude(
            id=message.sender.id
        ).only('email', 'username')

        context = {
            'sender_name': message.sender.username,
            'message_preview': message.content[:100],
            'conversation_id': message.conversation.id
        }

        for recipient in recipients:
            try:
                email = EmailMultiAlternatives(
                    subject=f"✉ Nouveau message de {message.sender.username}",
                    body=strip_tags(
                        render_to_string('messaging/email_notification.txt', context)
                    ),
                    from_email='messages@moncaisson.com',
                    to=[recipient.email],
                    reply_to=[message.sender.email]
                )
                email.attach_alternative(
                    render_to_string('messaging/email_notification.html', context),
                    "text/html"
                )
                email.send(fail_silently=False)
                
            except Exception as e:
                logger.error(f"Échec envoi à {recipient.email}: {str(e)}")

    except Message.DoesNotExist:
        logger.error(f"Message {message_id} introuvable")
    except Exception as e:
        logger.critical(f"Échec critique tâche: {str(e)}")
        raise self.retry(exc=e)